library(terra)
library(sf)
library(RColorBrewer)

# Charger le raster d’ombrage
ombrage <- rast("I:/Memoire/SIG/Rendu_Ceres_Flore/Data/Enrichissement/ombrage_table.tif")

# Reclassifier en 4 classes : 0–63 / 64–127 / 128–191 / 192–254
rcl <- matrix(c(0, 63, 1,
                64, 127, 2,
                128, 191, 3,
                192, 255, 4),  # 255 car la borne supérieure est exclusive
              ncol = 3, byrow = TRUE)

ombrage_class <- classify(ombrage, rcl)

# Vectoriser les classes avec fusion des polygones identiques
ombrage_vect <- as.polygons(ombrage_class, dissolve = TRUE, na.rm = TRUE)

# Ajouter des étiquettes descriptives (optionnel)
ombrage_vect$classe_label <- factor(ombrage_vect$ombrage_class,
                                    levels = 1:4,
                                    labels = c("Très ombragé", "Ombragé", "Exposé", "Très exposé"))

# Exporter en GeoPackage
writeVector(ombrage_vect,
            filename = "I:/Memoire/SIG/Rendu_Ceres_Flore/R/Export/ombrage_vectorise_4classes.gpkg",
            layer = "ombrage_4_classes",
            filetype = "GPKG",
            overwrite = TRUE)

