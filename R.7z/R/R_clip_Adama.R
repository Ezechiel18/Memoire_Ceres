library(terra)

# Charger les rasters et la zone (vectorielle)
r1 <- rast("I:/Memoire/SIG/Rendu_Ceres_Flore/R/Export/t_2055_mean_celsius.tif")
r2 <- rast("I:/Memoire/SIG/Rendu_Ceres_Flore/R/Export/t_2025_mean_celsius.tif")
zone <- vect("I:/Memoire/SIG/Temp/Mzone.gpkg")  # ou .geojson, .gpkg, etc.

# Reprojeter la zone dans le CRS de chaque raster
zone_pr <- project(zone, crs(r1))

# Découper les rasters avec l’emprise de la zone (clip spatial)
r1_crop <- crop(r1, zone_pr, mask=TRUE)
r2_crop <- crop(r2, zone_pr, mask=TRUE)

plot(r1_crop, main="Raster 2055 découpé")
plot(zone_pr, add=TRUE, border="red")


# Sauvegarder si besoin
writeRaster(r1_crop, "I:/Memoire/SIG/Rendu_Ceres_Flore/R/Export/clip_t2055.tif", overwrite=TRUE)
writeRaster(r2_crop, "I:/Memoire/SIG/Rendu_Ceres_Flore/R/Export/clip_t2025.tif", overwrite=TRUE)

