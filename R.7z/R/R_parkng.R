# ========== INSTALLER LES PACKAGES (à faire une seule fois) ==========
# install.packages(c("sf", "dplyr", "units", "lwgeom", "ggplot2"))

# ========== CHARGER LES PACKAGES ==========
library(sf)
library(dplyr)
library(units)
library(lwgeom)
library(ggplot2)

# ========== PARAMÈTRES À MODIFIER ==========
sites_path <- "I:/Memoire/SIG/Rendu_Ceres_Flore/Data/GPK/site_prelevement_2154.gpkg"
parkings_path <- "I:/Memoire/SIG/Rendu_Ceres_Flore/Data/Enrichissement/Parking_VF.geojson"
champ_superficie <- "Superficie_ha"
seuil_distance_externe <- set_units(1000, "m")
distance_min_entre_parkings <- set_units(150, "m")
champ_id <- "site_id"

# ========== CHARGEMENT ET PRÉPARATION DES DONNÉES ==========
sites <- st_read(sites_path)

# Nettoyage : suppression des géométries vides
sites <- sites[!st_is_empty(st_geometry(sites)), ]

# Conversion des superficies : virgule → point, puis en numérique
sites[[champ_superficie]] <- as.numeric(gsub(",", ".", sites[[champ_superficie]]))
sites <- sites[!is.na(sites[[champ_superficie]]), ]

# Ajout d'un identifiant unique si absent
if (!champ_id %in% names(sites)) {
  sites[[champ_id]] <- seq_len(nrow(sites))
}

# Lecture et reprojection des parkings
parkings <- st_read(parkings_path)
parkings <- st_transform(parkings, st_crs(sites))

# Jointure spatiale pour identifier les parkings à l'intérieur des sites
parkings_in_sites <- st_join(parkings, sites, join = st_within, left = FALSE)

# Correction du nom de la colonne d'ID si modifié après jointure
if (!champ_id %in% names(parkings_in_sites)) {
  possible_fid <- grep("^fid\\.|^fid$", names(parkings_in_sites), value = TRUE)
  if (length(possible_fid) == 1) {
    names(parkings_in_sites)[names(parkings_in_sites) == possible_fid] <- champ_id
  } else {
    stop("Impossible de trouver la colonne 'fid' après la jointure.")
  }
}

# ========== FONCTION DE FILTRAGE DES PARKINGS ==========
trouver_parkings_pour_site <- function(site) {
  site_geom <- site$geometry
  site_id <- site[[champ_id]]
  surface_ha <- site[[champ_superficie]]
  
  parkings_interne <- parkings_in_sites %>% filter(.data[[champ_id]] == site_id)
  
  if (nrow(parkings_interne) >= 1) {
    if (nrow(parkings_interne) == 1) {
      parking <- parkings_interne
    } else if (surface_ha < 5) {
      centre <- st_centroid(site_geom)
      distances <- st_distance(centre, parkings_interne)
      parking <- parkings_interne[which.min(distances), ]
    } else if (surface_ha >= 50) {
      keep <- c()
      for (i in 1:nrow(parkings_interne)) {
        if (length(keep) == 0) {
          keep <- c(keep, i)
        } else {
          dists <- st_distance(parkings_interne[i, ], parkings_interne[keep, ])
          if (all(dists > distance_min_entre_parkings)) {
            keep <- c(keep, i)
          }
        }
        if (length(keep) == 3) break
      }
      parking <- parkings_interne[keep, ]
    } else {
      keep <- c(1)
      for (i in 2:nrow(parkings_interne)) {
        dists <- st_distance(parkings_interne[i, ], parkings_interne[keep, ])
        if (all(dists > set_units(50, "m"))) {
          keep <- c(keep, i)
        }
        if (length(keep) == 2) break
      }
      parking <- parkings_interne[keep, ]
    }
    parking$origine <- "interne"
    parking[[champ_id]] <- site_id
    return(parking)
  }
  
  distances <- st_distance(site_geom, parkings)
  min_dist <- min(distances)
  if (min_dist < seuil_distance_externe) {
    parking_externe <- parkings[which.min(distances), ]
    parking_externe$origine <- "externe"
    parking_externe[[champ_id]] <- site_id
    return(parking_externe)
  } else {
    return(NULL)
  }
}

# ========== BOUCLE ROBUSTE SUR TOUS LES SITES ==========
liste_resultats <- list()
erreurs <- list()

for (i in seq_len(nrow(sites))) {
  cat("Traitement du site", i, "sur", nrow(sites), "\n")
  site <- sites[i, ]
  
  if (is.null(st_geometry(site)) || st_is_empty(st_geometry(site))) {
    cat("⚠️ Géométrie vide ou manquante pour le site", i, "\n")
    erreurs[[length(erreurs) + 1]] <- paste("Géométrie vide pour le site", i)
    next
  }
  
  tryCatch({
    result <- trouver_parkings_pour_site(site)
    if (!is.null(result)) {
      liste_resultats[[length(liste_resultats) + 1]] <- result
    }
  }, error = function(e) {
    cat("❌ Erreur pour le site", i, ":", conditionMessage(e), "\n")
    erreurs[[length(erreurs) + 1]] <- paste("Erreur site", i, ":", conditionMessage(e))
  })
}

# ========== COMBINAISON DES RÉSULTATS ==========
if (length(liste_resultats) > 0) {
  parkings_associes <- do.call(rbind, liste_resultats)
}
  # ========== VISUALISATION ==========
  ggplot() +
    geom_sf(data = sites, fill = "lightgreen", color = "darkgreen", alpha = 0.4) +
    geom_sf(data = parkings_associes, aes(color = origine), size = 2) +
    scale_color_manual(values = c("interne" = "blue", "externe" = "red")) +
    labs(title = "Parkings associés aux sites", color = "Origine du parking") +
    theme_minimal()
  
  # ========== EXPORT ==========
st_write(parkings_associes, "resultats/parkings_associes.shp", delete_layer = TRUE)
cat("✅ Export terminé avec", nrow(parkings_associes), "parkings associés.\n")
} else {
  cat("⚠️ Aucun parking n'a été associé aux sites.\n")
}
# ========== RAPPEL DES ERREURS ==========
if (length(erreurs) > 0) {
  cat("🚨 Liste des erreurs rencontrées :\n")
  print(erreurs)
}

  