# 1. Charger les packages nécessaires
library(terra)
library(sf)
library(RColorBrewer)

# 2. Charger les rasters de température moyenne
p_2025 <- rast("I:/Memoire/SIG/Rendu_Ceres_Flore/R/Export/pr_2025_mean.tif")
p_2055 <- rast("I:/Memoire/SIG/Rendu_Ceres_Flore/R/Export/pr_2055_mean.tif")

# 3. Calculer l’écart de température (2055 - 2025)
delta_prec <- p_2055 - p_2025

# 4. Visualiser avec une palette de couleurs adaptée
# Définir les couleurs : du bleu (refroidissement) au rouge (réchauffement)
pal <- colorRampPalette(rev(brewer.pal(11, "RdYlBu")))

# Créer une palette pour l’écart
plot(delta_prec,
     main = "Écart de précipitation 2055 - 2025 (mm)",
     col = pal(100),
     xlab = "Longitude", ylab = "Latitude")

# 5. Charger la limite administrative pour situer la zone
limite <- st_read("I:/Memoire/SIG/Rendu_Ceres_Flore/Data/GPK/region_interet_2154.gpkg")
limite <- st_transform(limite, crs(delta_prec))  # Harmoniser les projections
plot(vect(limite), add = TRUE, border = "black", lwd = 1)

# 6. Exporter le raster d’écart
writeRaster(delta_temp,
            filename = "I:/Memoire/SIG/Rendu_Ceres_Flore/R/Export/ecart_precip_2055_2025.tif",
            overwrite = TRUE)

# 7. Vectoriser l’écart (optionnel)
delta_vect <- as.polygons(delta_prec, dissolve = FALSE, na.rm = TRUE)
delta_vectt <- as.polygons(delta_prec, dissolve = TRUE, na.rm = TRUE)

# 8. Exporter le vecteur
writeVector(delta_vect,
            filename = "I:/Memoire/SIG/Rendu_Ceres_Flore/R/Export/ecart_precip_2055_2025_vector.gpkg",
            layer = "delta_prec",
            filetype = "GPKG",
            overwrite = TRUE)
writeVector(delta_vectt,
            filename = "I:/Memoire/SIG/Rendu_Ceres_Flore/R/Export/ecart_arrondi_precip_2055_2025_vector.gpkg",
            layer = "delta_prec",
            filetype = "GPKG",
            overwrite = TRUE)
