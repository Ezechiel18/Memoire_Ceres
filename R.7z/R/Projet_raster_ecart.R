# 1. Charger les packages nécessaires
library(terra)
library(sf)
library(RColorBrewer)

# 2. Charger les rasters de température moyenne
t_2025 <- rast("I:/Memoire/SIG/Rendu_Ceres_Flore/R/Export/t_2025_mean_celsius.tif")
t_2055 <- rast("I:/Memoire/SIG/Rendu_Ceres_Flore/R/Export/t_2055_mean_celsius.tif")

# 3. Calculer l’écart de température (2055 - 2025)
delta_temp <- t_2055 - t_2025

# 4. Visualiser avec une palette de couleurs adaptée
# Définir les couleurs : du bleu (refroidissement) au rouge (réchauffement)
pal <- colorRampPalette(rev(brewer.pal(11, "RdYlBu")))

# Créer une palette pour l’écart
plot(delta_temp,
     main = "Écart de température 2055 - 2025 (°C)",
     col = pal(100),
     xlab = "Longitude", ylab = "Latitude")

# 5. Charger la limite administrative pour situer la zone
limite <- st_read("I:/Memoire/SIG/Rendu_Ceres_Flore/Data/GPK/region_interet_2154.gpkg")
limite <- st_transform(limite, crs(delta_temp))  # Harmoniser les projections
plot(vect(limite), add = TRUE, border = "black", lwd = 1)

# 6. Exporter le raster d’écart
writeRaster(delta_temp,
            filename = "I:/Memoire/SIG/Rendu_Ceres_Flore/R/Export/ecart_temp_2055_2025.tif",
            overwrite = TRUE)

# 7. Vectoriser l’écart (optionnel)
delta_vect <- as.polygons(delta_temp, dissolve = FALSE, na.rm = TRUE)


# 8. Exporter le vecteur
writeVector(delta_vect,
            filename = "I:/Memoire/SIG/Rendu_Ceres_Flore/R/Export/ecart_temp_2055_2025_vector.gpkg",
            layer = "delta_temp",
            filetype = "GPKG",
            overwrite = TRUE)
